# Aviva AEM Dispatcher & Apache Configuration Generator

Uses Puppet to create promoted configuration files for the following environments:

- local
- ci 
- int
- demo
- dev
- qa
- staging
- production

## Usage

### Environment Configuration

The [environment YAML files](hiera/hieradata/env) define the environment-specific variables.  Configurations which apply to all environments are stored in the [common file](hiera/hieradata/common.yaml).

### Site Configuration

Each **site** (e.g. www.aviva.com) has its own farm and VirtualHost configuration file.  In order to create a new site the following need to be created or updated:
- Add new **site** entry in *sitefiles* list in the [**common YAML file**](hiera/hieradata/common.yaml)
- Create new farm configuration file named **site.any.erb** using [***site_url.any.erb***](puppet/environments/production/modules/aem/templates/conf/site_url.any.erb) as a template
- Create new VirtualHost configuration file named ***site_vhost.conf*** using an existing configuration in [**puppet/environments/production/modules/aem/files/conf/aviva_vhosts**](puppet/environments/production/modules/aem/files/conf/aviva_vhosts)


### Creating the Configuration Files
To create a set of configration files:

- Download and install the latest Puppet Agent (e.g. puppet-agent-x64-latest.msi) for [Windows](https://docs.puppet.com/puppet/latest/reference/install_windows.html), [Linux](https://docs.puppet.com/puppet/latest/reference/install_linux.html) or [OS X](https://docs.puppet.com/puppet/latest/reference/install_osx.html)
- Run [***puppet/go.cmd***](puppet/go.cmd) or [***puppet/go.sh***](puppet/go.sh) on Linux (e.g. from Jenkins)

### To configure Apache
Add at the bottom of /etc/httpd.conf: ***Include conf/aviva/*.conf"***

## Still To Do
- Populate QA/Staging/Production AMS environments with data once provided by Adobe.
- Confirm higher environment configuration with Adobe, in particular, the secondary Author instance.