#!/bin/bash

# Flush (clear down) the AEM cache directory. Recursively, all files and folders.

# Parameters:
# Call this script with the following parameters:
#     cache sub-directory name  - name of the cache sub-directory to clear, for example * or a specific
#                                 sub-directory of the cache root /mnt/var/www/html/.
#     maximum retries - the number of times to retry when getting "directory not found" errors.

# Note: To prevent accidental misuse, the cache directory will be hardcoded into this script (/mnt/var/www/html/ for AMS)

# Example usage:
#    cache_flush.sh '*' 30

# ** Notes for future maintainers: **
#
# Usually the "rm -rf" command will simply delete all sub-directories and files recursively.
# Usually there would be no need to have a loop applying rm -rf repeatedly.
# The cache directory is a special case because there are a great many files being written to
# it all the time, in real time. When the "rm -rf" command runs, internally it removes
# all files in a folder and then tries to remove the folder itself, only at that instant
# more and more cache files are written to the folder, so the rm command will give the error "Directory
# not found". This is the reason why there is a loop in this script which checks for that error, and
# retries a number of times until it is all cleared down. This script is executed from a Jenkins job
# which uploads the cache-flush.sh script to each dispatcher where it is run locally.

# Validate parameters

cache_subdir=$1
if [[ -z "$cache_subdir" ]]; then
   echo "ERROR: No cache sub-folder passed in parameters"
   exit 1
fi

max_retries=$2
if [ -z $max_retries ]; then
   echo "ERROR: No maximum retries (second parameter) specified"
   exit 1
fi

if ! [[ $max_retries =~ ^[0-9]+$ ]] ; then
   echo "ERROR: Maximum retries parameter must be an integer, for example 20. Found '$max_retries'"
   exit 1
fi

echo "Flushing cache path: /mnt/var/www/html/${cache_subdir}"
echo " Retry a maximum of: $max_retries times."
echo " "

# Prime the loop
retry_count=0
cache_flushed=false

# Loop until we clear all cache files without hitting the "Directory not empty" error
while [ $cache_flushed = false ] && [ $retry_count -lt $max_retries ]
do
   output_msg=$(sudo /bin/rm -rf /mnt/var/www/html/$cache_subdir 2>&1)
   if [[ "$output_msg" = *"Directory not empty"* ]]; then
      ((retry_count++))
      echo "  Pass $retry_count, flush incomplete, retrying ..."
   else
      cache_flushed=true
   fi
done

echo " "
if  [ $cache_flushed ]; then
   if [ $retry_count -eq 0 ]; then
     echo "Cache flushed successfully first time."
   else
     echo "Cache flushed successfully after $retry_count attempts."
   fi
   exit 0
else
   echo "Cache did not flush after $retry_count attempts."
   exit 1
fi
