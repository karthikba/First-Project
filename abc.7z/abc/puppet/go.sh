#!/bin/bash
export PATH=$PATH:/opt/puppetlabs/bin
export FACTER_outputfolder=`pwd`/output

rm -rf ./output
if [ "$1" ]
  then
    echo "Building for env $1 only"
    export FACTER_env=$1
puppet apply --modulepath=./environments/production/modules --hiera_config=../hiera/hiera.yaml ./environments/production/manifests/configs.pp
else
   for environment in `cat environments.txt`
   do 
      export FACTER_env=$environment
      puppet apply --modulepath=./environments/production/modules --hiera_config=../hiera/hiera.yaml ./environments/production/manifests/configs.pp
   done
fi
