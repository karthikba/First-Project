module Puppet::Parser::Functions

    newfunction(:create_lifecycle_domain_map, :type => :rvalue,:doc => <<-'END_DOC') do |args|
        Function create_lifecycle_domain_map

        This function creates a map of domains with the original domain as the key, and the lifecycle domain as the
        value.

        Usage :
            create_lifecycle_domain_map(array_of_sitehosts, env, environment_domain)
            create_lifecycle_domain_map(["hostA", "hostB"], env, environment_domain)
        END_DOC

        # Make sure arguments are the correct length
        unless args.length == 3
            raise Puppet::ParseError, ("create_lifecycle_domain_map(): wrong number of arguments (#{args.length}; must be 3)")
        end

        # make sure the first argument is an array
        sitefiles = args[0]
        unless sitefiles.is_a?(Array)
            raise(Puppet::ParseError, 'create_lifecycle_domain_map(): The first argument should be an array')
        end

        # get the other arguments
        env         = args[1]
        envdomain   = args[2]

        # add each site to the new hash
        domain_map = Hash.new
        sitefiles.each do |site|
            domain_map[site] = function_to_lifecycle_domain([site, env, envdomain])
        end

        return domain_map
    end
end