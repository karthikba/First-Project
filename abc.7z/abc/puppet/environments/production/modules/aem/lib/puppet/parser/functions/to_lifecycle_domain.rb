module Puppet::Parser::Functions
    newfunction(:to_lifecycle_domain, :type => :rvalue,:doc => <<-'END_DOC') do |args|
        Function to_lifecycle_domain

        This function converts a given domain value to the correct life-cycle equivalent of that domain

        Usage :
            to_lifecycle_domain(original_domain, env, environment_domain)
            to_lifecycle_domain("my.original.domain", "stg", "aviva.aws.com")

            || prod-my-original-domain.aviva.aws.com
        END_DOC

        # make sure arguments length is 3
        unless args.length == 3
            raise Puppet::ParseError, ("to_lifecycle_domain(): wrong number of arguments (#{args.length}; must be 3)")
        end

        # extraxt the values
        host       = args[0]
        env        = args[1]
        envdomain  = args[2]

        # special case for dealing with MyAviva or CaaS
        internals = ['myaviva', 'caas']
        if internals.include?(host)
            # in all environments the MyAviva and CaaS envdomains are avivaaws
            envdomain = '.aem.avivaaws.com'

            # for the prod env do not transform the url
            if env == 'prd'
                return host + '.aem.avivaaws.com'
            end
        end
		
        if env == 'prd'
		    # do not update the host value for production
		    return "#{host}"
        end

        # update the host value
        host = host.gsub ".", "-"

        return "#{env}-#{host}#{envdomain}"
    end
end